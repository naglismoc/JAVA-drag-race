
import java.util.Random;

public class Masina {
   private String marke;
   private int maxGreitis;
   private double kiekKmIveike;
   private double akseleracijaProcentais;
   private double dabartinisGreitis;

    public Masina(String marke, int maxGreitis,double kiekKmIveike,double akseleracijaProcentais,double dabartinisGreitis) {
        this.marke = marke;
        this.maxGreitis = maxGreitis;
        this.kiekKmIveike=kiekKmIveike;
        this.akseleracijaProcentais=akseleracijaProcentais;
        this.dabartinisGreitis=dabartinisGreitis;
    }

    public String getMarke() {
        return marke;
    }

    public void setMarke(String marke) {
        this.marke = marke;
    }

    public int getMaxGreitis() {
        return maxGreitis;
    }

    public void setMaxGreitis(int maxGreitis) {
        this.maxGreitis = maxGreitis;
    }

    public double getKiekKmIveike() {
        return kiekKmIveike;
    }

    public void setKiekKmIveike(double kiekKmIveike) {
        this.kiekKmIveike = kiekKmIveike;
    }

    public double getAkseleracijaProcentais() {
        return akseleracijaProcentais;
    }

    public void setAkseleracijaProcentais(double akseleracijaProcentais) {
        this.akseleracijaProcentais = akseleracijaProcentais;
    }

    public double getDabartinisGreitis() {
        return dabartinisGreitis;
    }

    public void setDabartinisGreitis(double dabartinisGreitis) {
        this.dabartinisGreitis = dabartinisGreitis;
    }


    public void   gazuojam(int i, int minutes){

        setDabartinisGreitis(getDabartinisGreitis()+getMaxGreitis()*(getAkseleracijaProcentais()/100));
        if (getDabartinisGreitis()>getMaxGreitis()){
            setDabartinisGreitis(getMaxGreitis());
        }
        setKiekKmIveike(getKiekKmIveike()+Math.round(getDabartinisGreitis()*100)/100/6);
        System.out.println(getMarke()+"  "+minutes+"-a minute pagazavo ir nuleke " +getDabartinisGreitis()+"km/h greiciu, is viso nuvaziavo "+getKiekKmIveike()+"km.");
    }



    public void stabdom(int i,int minutes){
        setDabartinisGreitis(getDabartinisGreitis()-getDabartinisGreitis()+(getAkseleracijaProcentais()/100));
        setKiekKmIveike(getKiekKmIveike()+Math.round(getDabartinisGreitis()*100)/100/6);
        if (getDabartinisGreitis()>=0){
            System.out.println(getMarke()+" sustojo");
        }
        else
        System.out.println(getMarke() +" "+minutes+"-a minute pristabde ir nuvaziavo " +Math.round(getDabartinisGreitis()*0.6)/100+"km/h greiciu, is viso nuvaziavo "+getKiekKmIveike()+"km.");

    }
    public void vaziuojam(int i,int minutes){
       // dabartinisGreitis=dabartinisGreitis-dabartinisGreitis*(akseleracijaProcentais/100);
        kiekKmIveike=kiekKmIveike+Math.round(dabartinisGreitis*100)/100/6;
        System.out.println(getMarke()+ " "+minutes+"-a minute vaziavo " +getDabartinisGreitis()+"km/h greiciu, is viso nuvaziavo "+getKiekKmIveike()+"km.");

    }

public int arKirtoFinisa(int i,int pirmaujancioPozicija){
    if (getKiekKmIveike()>pirmaujancioPozicija){
        pirmaujancioPozicija= (int) getKiekKmIveike();
    }
    return pirmaujancioPozicija;
}
    static int randomasIki100() {
        Random rnd = new Random();
        int randomInt = rnd.nextInt(100) + 1;
        return randomInt;
    }
}



