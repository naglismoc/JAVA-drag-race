import java.util.ArrayList;

import static java.lang.Integer.*;
import static java.util.Arrays.*;

public class Main {

    public static void main(String[] args) {
        ArrayList<Masina> masinos = new ArrayList<>();
        Masina fordas = new Masina("fordas",250,0,10,0);
        Masina feraris = new Masina("feraris",300,0,10,0);
        Masina lamborgini = new Masina("lamborgini",320,0,10,0);
        Masina bmw = new Masina("bmw",270,0,10,0);
        Masina audi = new Masina("audi",280,0,10,0);
        Masina mercedes = new Masina("mercedes",280,0,10,0);
        Masina bugati = new Masina("bugati",420,0,10,0);
        Masina maybach = new Masina("maybach",350,0,10,0);

        masinos.addAll(asList(fordas,feraris,lamborgini,bmw,audi,mercedes,bugati,maybach));

//        ArrayList<Masina> masinos2 = new ArrayList<>();
//        Masina petras = new Masina("petras",250,0,10,0);
//        Masina antanas = new Masina("antanas",250,0,10,0);
//
//        masinos2.add(petras);
//        masinos2.add(antanas);
//        masinos2.add(antanas);
//        System.out.println(masinos2.size()+"masinos2.size");



        int trasosIlgis=500;
        int pirmaujancioPozicija=0;
        int veiksmas;
        int minutes = 0;
        while (pirmaujancioPozicija<trasosIlgis) {
         minutes++;
            System.out.println("");
            for (int i = 0; i < masinos.size(); i++) {
                veiksmas=Masina.randomasIki100();
                if (masinos.get(i).getDabartinisGreitis()==0){
                    masinos.get(i).gazuojam(i,minutes);
                    pirmaujancioPozicija=  masinos.get(i).arKirtoFinisa(i,pirmaujancioPozicija);

                }

                    else {
                    if (veiksmas < 50) {
                        //   System.out.println(i+ " -a masina "+minutes+"-u minute pagazavo ir nuvaziavo " +masinos.get(i).gazuojam()+"km, is viso nuvaziavo "+masinos.get(i).getKiekKmIveike()+"km.");
                        masinos.get(i).gazuojam(i, minutes);
                        pirmaujancioPozicija= masinos.get(i).arKirtoFinisa(i, pirmaujancioPozicija);


                    } else if (veiksmas < 70) {
                        masinos.get(i).stabdom(i, minutes);
                        // System.out.println("stabdo");
                    } else {
                        masinos.get(i).vaziuojam(i, minutes);
                        // System.out.println("tiesiog vaziuoja");
                    }
                }

            }
        }
        for (int h=0; h<masinos.size();h++) {
            for (int j = 0; j < masinos.size(); j++) {
                for (int i = 0; i < masinos.size() - 1; i++) {
                    if (masinos.get(i).getKiekKmIveike() < masinos.get(i + 1).getKiekKmIveike()) {
                        masinos.add(masinos.get(i));
                        masinos.remove(masinos.get(i));
                        i--;
                    }
                }
            }
        }


        System.out.println("");
        System.out.println("masinas susortinau");
        System.out.println("-------------------");
        for (int i = 0; i<masinos.size();i++){
            System.out.println(masinos.get(i).getMarke()+" nuvaziavo "+masinos.get(i).getKiekKmIveike()+"km.");
        }

    }
}
